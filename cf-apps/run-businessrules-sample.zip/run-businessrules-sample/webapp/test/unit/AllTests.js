sap.ui.define([
	"sapwfm.sample./run-businessrules-sample/test/unit/controller/app.controller"
], function () {
	"use strict";
});
