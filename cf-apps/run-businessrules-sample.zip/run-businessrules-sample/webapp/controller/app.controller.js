sap.ui.define([
    "sap/ui/core/mvc/Controller"
],
	/**
	 * @param {typeof sap.ui.core.mvc.Controller} Controller
	 */
    function (Controller) {
        "use strict";
        var oController;
        var _orderBusyDialog;

        return Controller.extend("sap.wfm.sample.runbusinessrulessample.controller.app", {
            onInit: function () {
                oController = this;

                //var sampleRule = this.getRuleSample();
                var rulesModel = new sap.ui.model.json.JSONModel();
                rulesModel.Input = {};
                rulesModel.Output = {};
                oController.getView().setModel(rulesModel);
            },

            getRuleSample: function () {
                var sample = 
                   "{\"RuleServiceId\":\"f8ba21525ccb4cf18e0d91939b5fc58e\",\"RuleServiceRevision\":\"Trial\",\"Vocabulary\":[{\"Investment\":{\"Type\":\"Software\",\"Country\":\"Germany\",\"TotalCost\":1000}}]}";
                
                return sample;
            },

            onStartPress: function (oEvent) {
                // create busy dialog
                _orderBusyDialog = new sap.m.BusyDialog({});
                _orderBusyDialog.open();

                var rulesInputModel = this.getView().getModel().oData.Input;
        
                // Invoke Rules to get Discount and Shipping Cost
                $.ajax({
                    url: "/sap-wfm-sample-runbusinessrulessample.sapwfmsamplerunbusinessrulessample-1.0.0" + "/bpmrulesruntime/rules-service/rest/v2/xsrf-token",
                    method: "GET",
                    headers: {
                        "X-CSRF-Token": "Fetch"
                    },
                    success: function (result, xhr, data) {
                        var token = data.getResponseHeader("X-CSRF-Token");
                        if (token === null) return;

                        $.ajax({
                            url: "/sap-wfm-sample-runbusinessrulessample.sapwfmsamplerunbusinessrulessample-1.0.0" + "/bpmrulesruntime/rules-service/rest/v2/workingset-rule-services",
                            type: "POST",
                            data: JSON.stringify(JSON.parse(rulesInputModel)),
                            headers: {
                                "X-CSRF-Token": token,
                                "Content-Type": "application/json"
                            },
                            async: false,
                            success: function (data) {
                                _orderBusyDialog.close();
                                var viewModel = oController.getView().getModel().oData;
                                viewModel.Output = JSON.stringify(data.Result[0], null, 4);
                                oController.getView().setModel(new sap.ui.model.json.JSONModel(viewModel));
                            },
                            error: function (data) {
                                _orderBusyDialog.close();
                            }
                        });
                    }
                })
            }
        });
    });
