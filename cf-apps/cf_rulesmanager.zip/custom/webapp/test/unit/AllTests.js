sap.ui.define([
	"sap/demo/rules/custom/test/unit/controller/app.controller"
], function () {
	"use strict";
});