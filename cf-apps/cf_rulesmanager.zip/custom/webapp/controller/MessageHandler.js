sap.ui.define([
	"sap/ui/base/Object",
	"sap/demo/rules/custom/i18n/Translation",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"sap/m/Dialog",
	"sap/m/Button",
	"sap/m/Text",
	"sap/m/MessagePopover",
	"sap/m/MessagePopoverItem",
	"sap/ui/model/json/JSONModel"
], function(Object, Translator, MessageBox, MessageToast, Dialog,
			Button, Text, MessagePopover, MessageItem, JSONModel) {
	
	"use strict";
	
	return Object.extend("sap.demo.rules.custom.controller.MessageHandler", {
		
		/* Show error message based on i18n key or error response from OData call
		 * - Format for error response
		 *		{
		 *			"headers": [{...}, {...},...],
		 *			...
		 *			"responseText":
		 *				{
         *  				"error": {
		 *					"code": "<new codes would be created like bpm.rulesrepository.*>",
		 *          		"message": {
         *              		"lang": "en",
         *              		"value": "Data object does not exist"
		 *					}
		 *  			}
		 *			} 
		 *		}
		 * - if error with details needs to be raised, pass 'error' as 
		 *   '{responseText: "<required content>"}'
		 *
		 * @error : i18n key or oData error response
		 * @titleKey : title i18n key for error message box 
		 */
		 showErrorMessage: function(error, titleKey) {
			var oMessage;
			// set title for message box - default is Error
			var titleText = this._getTranslatedText(titleKey);
			if (!titleText) {
				titleText = this._getTranslatedText("ERROR");
			}
			// Get text based on error code
			if (typeof error === "string") { // text key provided
				oMessage = { msgText: "" };
				oMessage.msgText = this._getTranslatedText(error);
			} else { // error response object
				oMessage = this._getMessageObjectFromResponse(error);
			}
			// show error message with 'Show Details' in case detailText is set
			//var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			if (!oMessage.detailText) {
				MessageBox.error(oMessage.msgText, {
					title: titleText,
					styleClass: "" //bCompact ? "sapUiSizeCompact" : ""
				});
			} else {
				MessageBox.show(oMessage.msgText, {
					icon: MessageBox.Icon.ERROR,
					title: titleText,
					actions: [MessageBox.Action.OK],
					styleClass: "", //bCompact ? "sapUiSizeCompact" : "",
					details: oMessage.detailText
				});
			}
		},
		
		_getMessageObjectFromResponse: function(oResponseData) {
			var oMessage = {
				msgText: "",
				detailText: ""
			};
			// Get text based on error code, or else from error message or response text
			if (oResponseData && oResponseData.responseText) {
				try {
					var oResponse = JSON.parse(oResponseData.responseText);
					if (oResponse && oResponse.error) {
						if (oResponse.error.code) {
							oMessage.msgText = this._getTranslatedText(oResponse.error.code);
						} 
						// for empty/unsupported codes - unknown error, detailText = error message from backend
						if (!oMessage.msgText && oResponse.error.message) {
							oMessage.detailText = oResponse.error.message.value;
						}
					}
				} catch (e) { 
					// invalid responseText - unknown error, detailText = responseText
					oMessage.msgText = "";
				}
			}
			// for empty message text - unknown error with detail text
			if (!oMessage.msgText) {
				oMessage.msgText = this._getTranslatedText("UNKNOWN_ERROR");
				if (!oMessage.detailText) {
					oMessage.detailText = oResponseData.responseText;
				}
			}
			return oMessage;
		},
		
		_getTranslatedText: function(sKey, args) {
			return Translator.getText(sKey, args);
		},
		
		showInfoMessage: function(msgKey, titleKey) {
			var titleText = this._getTranslatedText(titleKey);
			//var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			MessageBox.information(this._getTranslatedText(msgKey), {
				title: titleText ? titleText : this._getTranslatedText("INFORMATION"),
				styleClass: "" //bCompact ? "sapUiSizeCompact" : ""
			});
		},
		
		showSuccessMessage: function(msgKey, aContextInfo) {
			MessageToast.show(this._getTranslatedText(msgKey, aContextInfo));
		},
		
		showDialogMessage: function(titleKey, msgKey, beginButtonTextKey, endButtonTextKey, fnBeginButton, fnEndButton) {
			var titleText = this._getTranslatedText(titleKey);
			var oDialog = new Dialog({
				title: titleText ? titleText : this._getTranslatedText("WARNING"),
				type: sap.m.DialogType.Message,
				state: sap.ui.core.ValueState.Warning,
				content: new Text({
					text: this._getTranslatedText(msgKey)
				}),
				afterClose: function() {
					oDialog.destroy();
				}
			});
			oDialog.setBeginButton(this._setDialogButton(oDialog, beginButtonTextKey, fnBeginButton));
			oDialog.setEndButton(this._setDialogButton(oDialog, endButtonTextKey, fnEndButton));
			oDialog.open();
		},

		_setDialogButton: function(oDialog, buttonTextKey, fnButton) {
			if (buttonTextKey) {
				return new Button({
					text: this._getTranslatedText(buttonTextKey),
					press: function() {
						if (fnButton) {
							fnButton();
						}
						oDialog.close();
					}
				});
			}
		},
		
		_renderMessagePopover: function(oSource, oMessageData) {
			// set message popover item template
			var oMessageTemplate = new MessageItem({
				type: '{type}',
				title: '{title}',
				description: '{description}',
				subtitle: '{subtitle}'
				// counter: '{counter}'
			});
			// set message popover
			var oMessagePopover = new MessagePopover({
				items: {
					path: '/',
					template: oMessageTemplate
				},
				afterClose: function(){
					this.destroy();
				}
			});
			// set model for message popover
			var oModel = this._getMessagePopoverModel();
			oModel.setData(oMessageData);
			oMessagePopover.setModel(oModel);
			// display message popover
			oMessagePopover.openBy(oSource);
		},
		
		_getMessagePopoverModel: function() {
			if (!this._oMessagePopoverModel) {
				this._oMessagePopoverModel = new JSONModel();
			}
			this._oMessagePopoverModel.setData([]);
			return this._oMessagePopoverModel;
		},
		
		/* Show list of message via Message Popover
		 * - Format for response from validate function:
		 *		{
         *  		"error/warning": {
		 *				"code": "<new codes would be created like bpm.rulesrepository.*>",
		 *          	"message": "Data object does not exist", 
		 *          	"details": [
         *              	{
         *              		"severity": "warning|error",
         *                  	"message": ""
		 *					}
    	 *            		...
		 *      		]
		 *  		}
		 *		} 
		 * @msgData : JSON string containing messages
		 * @oSource : source UI control
		 * @successMsgKey : message key in case no errors exist by checking response type
		 */
		showMessages: function(msgData, oSource, successMsgKey) {
			var that = this;
			if (msgData) {
				var oMessageData;
				// get error response from JSON string
				try {
					oMessageData = JSON.parse(msgData);
				} catch (oError) {
					$.sap.log.error(this._getTranslatedText("LOG_ERROR_INVALID_RESPONSE"));
					this.showErrorMessage(oError);
					return false;
				}
				if (oMessageData.type === "Success") {
					this.showSuccessMessage(successMsgKey);
				} else if (oMessageData.details) {
					// get message title from error code (fallback - set message for unknown error)
					var msgTitle = this._getTranslatedText(oMessageData.code, [""]);
					if (!msgTitle || msgTitle === oMessageData.code) {
						msgTitle = oMessageData.message;
					}
					// set message list
					var aMessages = [], msgText;
					jQuery.each(oMessageData.details, function(index, oDetail) {
						// get message from error 'code' (fallback - get text from backend sent 'message')
						msgText = that._getTranslatedText(oDetail.code, (oDetail.contextInfo ? oDetail.contextInfo : [""]));
						if (!msgText || msgText === oDetail.code) {
							msgText = oDetail.message;
						}
						// push message item into array of messages
						aMessages.push({
							type: oDetail.severtity,
							title: msgTitle,
							description: msgText, 
							subtitle: msgText
						});
					});
					// display message popover
					if (aMessages.length > 0) {
						this._renderMessagePopover(oSource, aMessages);
					}
				}
			}
		},
		
		/* 
		showMultiDeleteMessagePopOver: Show list of message via Message Popover for mass delete scenario
		@oSource : source UI control
		@aSuccessList : array of successful responses. Each entry contains following properties
						oResponse : the odata response for delete request
						aContexts : optional context information for message key
		@aErrorList : array of failed responses. Each entry contains following properties
						oResponse : the odata response for delete request
						Name : name of the entity (optional)
		@sKeySingleSuccess : message key for delete success for single entity
		@sKeySingleError : message key for delete error for single entity
		*/
		showMultiDeleteMessagePopOver: function(oSource, aSuccessList, aErrorList, sKeySingleSuccess, sKeySingleError) {
			var that = this;
			var aMessages = [], sTitleText;
			
			jQuery.each(aSuccessList, function(index, oResponse) {
				sTitleText = that._getTranslatedText(sKeySingleSuccess, oResponse.aContexts);
				aMessages.push({
					type: "Success",
					title: sTitleText
				});
			});
			
			jQuery.each(aErrorList, function(index, oResponse) {
				sTitleText = that._getTranslatedText(sKeySingleError, oResponse.aContexts);
				// get details of the message 
				var sDetailError = that.getDetailedErrorText(oResponse.oResponse);
				aMessages.push({
					type: "Error",
					title: sTitleText,
					description: sDetailError ? sDetailError : sTitleText, 
					subtitle: sDetailError ? sDetailError : sTitleText
				});
			});
			
			// display message popover
			if (aMessages.length > 0) {
				this._renderMessagePopover(oSource, aMessages);
			}
		},
		
		/*
		getDetailedErrorText: extracts the details from an error object oErrorData.
		format for oErrorData:
		{
			body: {
				error: {
					code: "< bpm.rulesrepository.ruleset.invalidid >",
					message: {
						value: "Data object does not exist"
					}
				}
			}
		}
		*/
		getDetailedErrorText: function(oErrorData) {
			
			try {
				oErrorData = JSON.parse(oErrorData.body);
			} catch (oError) {
				$.sap.log.error(this._getTranslatedText("LOG_ERROR_INVALID_RESPONSE"));
				return false;
			}
			
			var sDetailError = "";
			if (oErrorData.error && oErrorData.error.code) {
				sDetailError = this._getTranslatedText(oErrorData.error.code);
				if (!sDetailError || sDetailError === oErrorData.error.code) {
					if (oErrorData.error.message && oErrorData.error.message.value) {
						sDetailError = oErrorData.error.message.value;
					}
				}
			}
			
			return sDetailError;
		}
		
	});
});