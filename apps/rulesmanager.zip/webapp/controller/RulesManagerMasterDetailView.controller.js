sap.ui.define([
	"sap/rulesserviceRulesManager/controller/MessageHandler",
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/rules/ui/services/ExpressionLanguage",
	"sap/ui/commons/TextView",
	"sap/m/Dialog",
	"sap/ui/model/resource/ResourceModel",
	"sap/ui/model/Filter"
], function (MessageHandler, Controller) {
	"use strict";

	var oVocabularyJson;
	var ruleId;
	var ruleType;
	var ruleVersion;
	var projectId;
	var busyDialog = new sap.m.BusyDialog();

	return Controller.extend("sap.rulesserviceRulesManager.controller.RulesManagerMasterDetailView", {

		loadRulesBuilderControl: function (oProjectId, oRuleId, oRuleVersion, oRuleName, oRuleType) {
			busyDialog.open();

			projectId = oProjectId;
			ruleId = oRuleId;
			ruleVersion = oRuleVersion;
			ruleType = oRuleType;

			// apply compact density for desktop, the cozy design otherwise
			this.getView().addStyleClass(sap.ui.Device.system.desktop ? "sapUiSizeCompact" : "sapUiSizeCozy");

			var sVocabularyPath = "/Vocabularies('" + projectId + "')";
			var oExpressionLanguage;

			// Initialize Expression Language services
			this.oVocabularyModel = new sap.ui.model.odata.v2.ODataModel({
				serviceUrl: "/bpmrulesrepository/vocabulary_srv/",
				defaultBindingMode: sap.ui.model.BindingMode.TwoWay,
				defaultCountMode: sap.ui.model.odata.CountMode.None
			});

			// Initialize the Rule Builder
			this.oRuleModel = new sap.ui.model.odata.v2.ODataModel({
				serviceUrl: "/bpmrulesrepository/rule_srv/",
				defaultBindingMode: sap.ui.model.BindingMode.TwoWay,
				defaultCountMode: sap.ui.model.odata.CountMode.None
			});

			var oRuleBuilder = sap.ui.getCore().byId("ruleBuilder");
			oRuleBuilder.destroyDecisionTableConfiguration();
			oRuleBuilder.destroyTextRuleConfiguration();
			oRuleBuilder.setModel(this.oRuleModel);

			var oRulesConfig;
			if (ruleType === "DT") {
				oRuleBuilder.setTypes([sap.rules.ui.RuleType.DecisionTable]);
				oRulesConfig = new sap.rules.ui.DecisionTableConfiguration({
					enableSettings: true
				});
				oRuleBuilder.setDecisionTableConfiguration(oRulesConfig);
			} else if (ruleType === "TR") {
				oRuleBuilder.setTypes([sap.rules.ui.RuleType.TextRule]);
				oRulesConfig = new sap.rules.ui.TextRuleConfiguration({
					enableSettings: true
				});
				oRuleBuilder.setTextRuleConfiguration(oRulesConfig);
			}

			var that = this;
			this.oVocabularyModel.read(sVocabularyPath, {
				urlParameters: {
					"$expand": "DataObjects/Associations,DataObjects/Attributes,ValueSources"
				},
				success: function (data) {
					if (ruleType === "DT") {

						if (!oExpressionLanguage) {
							oExpressionLanguage = new sap.rules.ui.services.ExpressionLanguage();
							oRuleBuilder.setExpressionLanguage(oExpressionLanguage);
						}
						oExpressionLanguage.setData(data);
						oExpressionLanguage.setModel(that.oVocabularyModel);

						oVocabularyJson = data;
						oRuleBuilder.setBindingContextPath("/Rules(Id='" + ruleId + "',Version='" + ruleVersion + "')");
					} else if (ruleType === "TR") {
						if (!oExpressionLanguage) {
							oExpressionLanguage = new sap.rules.ui.services.ExpressionLanguage();
							oExpressionLanguage.setData(data);
							oExpressionLanguage.setModel(that.oVocabularyModel);
							oExpressionLanguage.setBindingContextPath("/Vocabularies(" + projectId + ")");
							oRuleBuilder.setExpressionLanguage(oExpressionLanguage);
						}
						oVocabularyJson = data;
						oRuleBuilder.setBindingContextPath(
							"/Projects(Id='" + projectId + "',Version='000001')/Rules(Id='" + ruleId + "',Version='" + ruleVersion + "')");

					}
					busyDialog.close();
				}
			});
		},

		setResultDataObject: function () {
			var oRuleBuilder = sap.ui.getCore().byId("ruleBuilder");
			var oRuleModel = oRuleBuilder.getModel();
			var sRulePath = oRuleBuilder.getBindingContextPath();

			oRuleModel.read(sRulePath, {
				success: function () {
					var sResultDataObjectIdProp = sRulePath + "/ResultDataObjectId";
					var sResultDataObjectId = oRuleModel.getProperty(sResultDataObjectIdProp);
					//If no result data object id provided, take default from Vocabulary
					if (!sResultDataObjectId && oVocabularyJson.DataObjects && oVocabularyJson.DataObjects.results) {
						oVocabularyJson.DataObjects.results.forEach(function (oDataObject) {
							if (oDataObject.Usage === "RESULT" && !sResultDataObjectId) {
								sResultDataObjectId = oDataObject.Id;
							}
						});
						if (sResultDataObjectId) {
							oRuleModel.callFunction("/SetRuleResultDataObject", {
								method: "POST",
								urlParameters: {
									"RuleId": ruleId,
									"ResultDataObjectId": sResultDataObjectId
								},
								success: function (oRuleModel2, oResponseData2) {
									oRuleModel.refresh();
								},
								error: function (oError) {
									sap.m.MessageBox.error(oError);
								}
							});
						}
					}
				}
			});
		},

		handleActionPress: function (oFIParam) {
			var _oMessageHandler;
			var hasResponseErrors = function (oResponseData) {
				var sError;
				if (oResponseData.__batchResponses) {
					oResponseData.__batchResponses.forEach(function (oResponse) {
						if (oResponse.response) {
							var oJsonMessage = JSON.parse(oResponse.response.body);
							if (oJsonMessage.error) {
								sError = sError + oJsonMessage.error.message.value + " (" + oJsonMessage.error.code + ")" + "\n";
							}
						}
					});
				}
				return sError;
			};

			var performFunctionImport = function (oResponseData, oInFIParam) {
				if (!oResponseData || !hasResponseErrors(oResponseData)) {
					oInFIParam.ruleBuilder.getModel().callFunction("/" + oInFIParam.name, {
						method: oInFIParam.method,
						urlParameters: {
							"RuleId": ruleId
						},
						success: oInFIParam.success,
						error: function (oError) {
							busyDialog.close();
							if (!_oMessageHandler) {
								jQuery.sap.require("sap.rulesserviceRulesManager.controller.MessageHandler");
								_oMessageHandler = new sap.rulesserviceRulesManager.controller.MessageHandler();
							}
							_oMessageHandler.showErrorMessage(oError);
						}
					});
				}
			};
			if (oFIParam.ruleBuilder.getModel().hasPendingChanges()) {
				oFIParam.ruleBuilder.getModel().submitChanges({
					success: function (oResponseData) {
						return performFunctionImport(oResponseData, oFIParam);
					},
					error: function (oError) {
						busyDialog.close();
						if (!_oMessageHandler) {
							jQuery.sap.require("sap.rulesserviceRulesManager.controller.MessageHandler");
							_oMessageHandler = new sap.rulesserviceRulesManager.controller.MessageHandler();
						}
						_oMessageHandler.showErrorMessage(oError);
					}
				});
			} else {
				return performFunctionImport(null, oFIParam);
			}
		},

		onSavePress: function () {
			busyDialog.open();
			var ruleBuilderId = sap.ui.getCore().byId("ruleBuilder");
			var oFIParam = {
				name: "SaveRule",
				ruleBuilder: ruleBuilderId,
				method: "POST",
				success: function (oResponseData) {
					busyDialog.close();
					sap.m.MessageToast.show("Rule is saved successfully");

					//After save version may increase to 000002, then rebind is required
					var sRulePath = "Rules(Id='" + ruleId + "',Version='" + "000002" + "'" + ")";
					ruleBuilderId.setBindingContextPath("/" + sRulePath);

				}.bind(this)
			};
			this.handleActionPress(oFIParam);
		},

		onActivatePress: function () {
			busyDialog.open();
			var ruleBuilderId = sap.ui.getCore().byId("ruleBuilder");
			var oFIParam = {
				name: "ActivateRule",
				ruleBuilder: ruleBuilderId,
				method: "POST",
				success: function (oResponseData) {
					busyDialog.close();
					sap.m.MessageToast.show("Rule is saved and activated successfully");

					ruleBuilderId.setEditable(false);
					sap.ui.getCore().byId("Edit").setVisible(true);
					sap.ui.getCore().byId("Deploy").setVisible(true);
					sap.ui.getCore().byId("Validate").setVisible(false);
					sap.ui.getCore().byId("Save").setVisible(false);
					sap.ui.getCore().byId("Activate").setVisible(false);
					sap.ui.getCore().byId("Cancel").setVisible(false);
				}.bind(this)
			};
			this.handleActionPress(oFIParam);
		},

		onEditPress: function () {
			var ruleBuilderId = sap.ui.getCore().byId("ruleBuilder");

			//********* INSERT THE CODE HERE **************************
			var oFIParam = {
				name: "EditRule",
				ruleBuilder: ruleBuilderId,
				method: "POST",
				success: function (oResponseData) {
					ruleBuilderId.setEditable(true);
					sap.ui.getCore().byId("Edit").setVisible(false);
					sap.ui.getCore().byId("Deploy").setVisible(false);
					sap.ui.getCore().byId("Validate").setVisible(true);
					sap.ui.getCore().byId("Save").setVisible(false);
					sap.ui.getCore().byId("Activate").setVisible(true);
					sap.ui.getCore().byId("Cancel").setVisible(true);
				}.bind(this)
			};
			this.handleActionPress(oFIParam);
		},

		onCancelPress: function () {
			var ruleBuilderId = sap.ui.getCore().byId("ruleBuilder");
			var oFIParam = {
				name: "DeleteRuleDraft",
				ruleBuilder: ruleBuilderId,
				method: "POST",
				success: function (oResponseData) {
					var oRuleModel = ruleBuilderId.getModel();
					oRuleModel.resetChanges();
					oRuleModel.refresh(true, true);
				}.bind(this)
			};

			var oController = this;
			sap.m.MessageBox.show(
				"Do you really want to cancel your changes?", {
					icon: sap.m.MessageBox.Icon.QUESTION,
					title: "Cancel Rule Changes",
					actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
					onClose: function (sAction) {
						if (sAction === sap.m.MessageBox.Action.YES) {
							oController.handleActionPress(oFIParam);
							ruleBuilderId.setEditable(false);
							sap.ui.getCore().byId("Edit").setVisible(true);
							sap.ui.getCore().byId("Validate").setVisible(false);
							sap.ui.getCore().byId("Save").setVisible(false);
							sap.ui.getCore().byId("Activate").setVisible(false);
							sap.ui.getCore().byId("Deploy").setVisible(false);
							sap.ui.getCore().byId("Cancel").setVisible(false);
						} else {
							oController.ruleBuilderId.setEditable(true);
							sap.ui.getCore().byId("Edit").setVisible(false);
							sap.ui.getCore().byId("Save").setVisible(true);
							sap.ui.getCore().byId("Validate").setVisible(true);
							sap.ui.getCore().byId("Activate").setVisible(true);
							sap.ui.getCore().byId("Deploy").setVisible(false);
							sap.ui.getCore().byId("Cancel").setVisible(true);
						}
					}
				}
			);
		},

		onCheckPress: function () {
			busyDialog.open();
			var ruleBuilderId = sap.ui.getCore().byId("ruleBuilder");
			var oFIParam = {
				name: "CheckRule",
				ruleBuilder: ruleBuilderId,
				method: "GET",
				success: function (oResponseData) {
					busyDialog.close();
					sap.m.MessageToast.show("Rule is validated successfuly");
				}
			};
			this.handleActionPress(oFIParam);
		},

		onSearch: function (oEvt) {
			// add filter for search
			var aFilters = [];
			var sQuery = oEvt.getSource().getValue();
			if (sQuery && sQuery.length > 0) {
				var filter = new sap.ui.model.Filter("Name", sap.ui.model.FilterOperator.Contains, sQuery);
				aFilters.push(filter);
			}

			// update list binding
			var projectList = sap.ui.getCore().byId("RulesProjectTreeList");
			var binding = projectList.getBinding("items");
			binding.filter(aFilters, "Application");
		},

		onExit: function () {
			sap.ui.getCore().byId("RulesManagerApp").destroy();
		}

	});
});