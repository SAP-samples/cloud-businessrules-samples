jQuery.sap.declare("sap.rulesserviceRulesManager.i18n.Translation");

sap.rulesserviceRulesManager.i18n.Translation = {

	resourceModels: {},
    resourceBundles: {},
    resourceBundlePath: "i18n/i18n.properties",

    /**
     * Get the translated text for the given key
     * 
     * @param {string}
     *            key String which defines the key in messages[language].properties
     * @param {array}
     *            args Array of stings which are included in the string
     * @returns {string} translated text
     */
    getText: function(key, args) {
    	"use strict";
        var messageBundle = this._getResourceBundle();
        return messageBundle.getText(key, args || []);
    },

    getResourceModel: function(bundleUrl) {
        "use strict";
        if (!bundleUrl) {
            bundleUrl = this._getResourceBundlePath();
        }
        if (!this.resourceModels[bundleUrl]) {
            var resourceModel = new sap.ui.model.resource.ResourceModel({
                bundleUrl: bundleUrl
            });
            this.resourceModels[bundleUrl] = resourceModel;
        }
        return this.resourceModels[bundleUrl];
    },

    _getResourceBundle: function() {
        "use strict";
        return this._getBundle(this._getResourceBundlePath());
    },

    _getBundle: function(bundleUrl) {
        "use strict";
        if (!this.resourceBundles[bundleUrl]) {
            var locale = sap.ui.getCore().getConfiguration().getLanguage();
            this.resourceBundles[bundleUrl] = this._loadBundle(bundleUrl, locale);
        }
        return this.resourceBundles[bundleUrl];
    },

    _loadBundle: function(bundleUrl, locale) {
        "use strict";
        return jQuery.sap.resources({
            url: bundleUrl,
            locale: locale
        });
    },

    _getResourceBundlePath: function() {
        "use strict";
        return this.resourceBundlePath;
    }
};