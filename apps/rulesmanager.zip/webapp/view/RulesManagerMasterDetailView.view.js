sap.ui.jsview("sap.rulesserviceRulesManager.view.RulesManagerMasterDetailView", {

			/** Specifies the Controller belonging to this View. 
			 * In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
			 * @memberOf controller.RulesManagerMasterDetailView
			 */
			getControllerName: function () {
				return "sap.rulesserviceRulesManager.controller.RulesManagerMasterDetailView";
			},

			/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
			 * Since the Controller is given to this method, its event handlers can be attached right away.
			 * @memberOf controller.RulesManagerMasterDetailView
			 */
			createContent: function (oController) {
				var controller = oController;

				var oSplitter = new sap.m.SplitApp({
					id: "RulesManagerApp"
				});

				var header = new sap.m.ObjectHeader({
					id: "rulesDetailsHeader"
				});

				var decisionTable = new sap.rules.ui.RuleBuilder({
					id: "ruleBuilder",
					editable: false
				});

				// 1, Initialize Rule Builder control and Buttons
				var cancelButton = new sap.m.Button({
					id: "Cancel",
					text: "Cancel",
					visible: false,
					type: sap.m.ButtonType.Reject,
					press: function (oControlEvent) {
						controller.onCancelPress();
					}
				});

				var checkButton = new sap.m.Button({
					id: "Validate",
					text: "Validate",
					visible: false,
					type: sap.m.ButtonType.Accept,
					press: function (oControlEvent) {
						controller.onCheckPress();
					}
				});

				var editButton = new sap.m.Button({
					id: "Edit",
					text: "Edit",
					visible: true,
					type: sap.m.ButtonType.Accept,
					press: function (oControlEvent) {
						controller.onEditPress();
					}
				});

				var saveButton = new sap.m.Button({
					id: "Save",
					text: "Save",
					visible: false,
					type: sap.m.ButtonType.Accept,
					press: function (oControlEvent) {
						controller.onSavePress();
					}
				});

				var activateButton = new sap.m.Button({
					id: "Activate",
					text: "Activate",
					visible: false,
					type: sap.m.ButtonType.Accept,
					press: function (oControlEvent) {
						controller.onActivatePress();
					}
				});

				var deployButton = new sap.m.Button({
						id: "Deploy",
						text: "Deploy",
						visible: false,
						type: sap.m.ButtonType.Accept,
						press: function (oControlEvent) {
							var busyDialog = new sap.m.BusyDialog();
							busyDialog.open();

							var detailsPageHeaderModel = sap.ui.getCore().byId("rulesDetailsHeader").getModel();
							var ruleServicesModel = detailsPageHeaderModel.Ruleservices;

							var isDeployed = false;
							var errorMessages = "";

							// A rule can be associated to multiple ruleservices. Deploy all the rule services
							for (var rsIndex = 0; rsIndex <= ruleServicesModel.length - 1; rsIndex++) {
								var payload = {};
								//payload.ProjectName = detailsPageHeaderModel.ProjectName;
								payload.RuleServiceId = ruleServicesModel[rsIndex];

								$.ajax({
										url: "/bpmrulesruntime/rest/v2/xsrf-token",
										method: "GET",
										contentType: "application/json",
										datatype: "json",
										async: false,
										headers: {
											"X-CSRF-Token": "Fetch"
										},
										success: function (resultXCRF, xhrRuleXCRF, dataRuleXCRF) {
											var token = dataRuleXCRF.getResponseHeader("X-CSRF-Token");

											$.ajax({
													url: "/bpmrulesruntime/rest/v2/workingset-rule-definitions",
													method: "POST",
													contentType: "application/json",
													data: JSON.stringify(payload),
													datatype: "json",
													async: false,
													headers: {
														"X-CSRF-Token": token
													},
													success: function (resultRuleDeploy, xhrRuleDeploy, dataRuleDeploy) {
														isDeployed = true;
													},
													error: function (oError) {
														isDeployed = false;
														if (oError.responseJSON !== null && oError.responseJSON.error !== null && oError.responseJSON.error.details !== null) {

															if (oError.responseJSON.error.details.length > 0) {
																errorMessages.concat(oError.responseJSON.error.details[0].message);
															} else {
																errorMessages.concat(oError.responseJSON.error.message);
																}
															} else {
																errorMessages.concat(oError.responseText);
															}

															errorMessages.concat("\n");
														}
													});
											}
										});
								}

								busyDialog.close();
								if (isDeployed) {
									sap.m.MessageToast.show("Rule deployed successfully");

									decisionTable.setEditable(false);
									editButton.setVisible(true);
									checkButton.setVisible(false);
									activateButton.setVisible(false);
									deployButton.setVisible(true);
									cancelButton.setVisible(false);
								} else {
									sap.m.MessageBox.error(errorMessages);
								}
							}
						});

					// 2. Define Master-Details page
					var rulesProjectsListTemplate = new sap.m.StandardTreeItem({
						title: "{Name}"
					});

					var rulesProjectsList = new sap.m.Tree({
						id: "RulesProjectTreeList",
						mode: sap.m.ListMode.SingleSelectMaster,
						selectionChange: function (oEvent) {
							var listItemModel = oEvent.getParameter("listItem").getBindingContext();
							var oModelSelected = listItemModel.getModel().getData().modeldata;
							var path = listItemModel.sPath;
							var tokens = path.split("/");

							var projectIndex = tokens[2];
							var selectedProjectModel = oModelSelected[projectIndex];
							var selProjectId = selectedProjectModel.Id;

							var ruleIndex = tokens[4];
							var selectedRuleModel = selectedProjectModel.Rules[ruleIndex];
							var selRuleId = selectedRuleModel.Id;
							var selRuleName = selectedRuleModel.Name;
							var selRuleDesc = selectedRuleModel.Description;
							var selRulesType = selectedRuleModel.Type;
							var selExprLang = selectedRuleModel.ExpressionLanguage;
							var selRulesVersion = "000001";

							// As REST API does not give rules version, need to explicitly call OData API
							var ruleVersions = [];
							$.ajax({
								url: "/bpmrulesrepository/rule_srv/Rules?$format=json",
								method: "GET",
								contentType: "application/json",
								datatype: "json",
								async: false,
								success: function (resultRules, xhrRules, dataRules) {
									var results = resultRules.d.results;
									results.filter(function (rule) {
										if (rule.Id === selRuleId) {
											ruleVersions.push(rule.Version);
											return;
										}
									});
								}
							});

							// This is one stupid logic as OData APIs returns 2 rules of same ID but different versions
							if (ruleVersions.length == 1) {
								selRulesVersion = "000001";
							} else {
								selRulesVersion = "000002";
							}

							// Get the ruleservice name for this selected rule
							$.ajax({
								url: "/bpmrulesrepository/rest/v1/projects/" + selProjectId + "/rulesets",
								method: "GET",
								contentType: "application/json",
								datatype: "json",
								async: false,
								success: function (resultRuleset, xhrRuleset, dataRuleset) {
									var rulesetsContainingRules = [];
									var ruleservices = [];
									resultRuleset.filter(function (ruleset) {
										var rules = ruleset.Rule;
										rules.filter(function (rule) {
											if (rule.ObjectId === selRuleId) {
												ruleservices.push(ruleset.RuleService.ObjectId);
												rulesetsContainingRules.push(ruleset);
											}
										});
									});

									selectedRuleModel.Ruleservices = [];

									for (var rsIndex = 0; rsIndex <= ruleservices.length - 1; rsIndex++) {
										var ruleServiceId = ruleservices[rsIndex];
										$.ajax({
											url: "/bpmrulesrepository/rest/v1/projects/" + selProjectId + "/ruleservices/" + ruleServiceId,
											method: "GET",
											contentType: "application/json",
											datatype: "json",
											async: false,
											success: function (resultRuleservice, xhrRuleservice, dataRuleservice) {
												selectedRuleModel.Ruleservices.push(resultRuleservice.Id);
											}
										});
									}
								}
							});

							// Reset the header for selected rule
							header.setModel(selectedRuleModel);
							header.setIcon("/webapp/icons/BusinessRulesIcon.png");
							header.setTitle(selRuleName);
							header.removeAllAttributes();
							header.addAttribute(new sap.m.ObjectAttribute({
								text: "Description: " + selRuleDesc
							}));

							header.setVisible(true);
							controller.loadRulesBuilderControl(selProjectId, selRuleId, selRulesVersion, selRuleName, selRulesType, selExprLang);

							var detailsPage = sap.ui.getCore().byId("RuleDetailsPage");
							detailsPage.setShowFooter(true);
							detailsPage.setShowHeader(true);
							oSplitter.toDetail("RuleDetailsPage");
						}
					});

					$.ajax({
						url: "/bpmrulesrepository/rest/v1/projects",
						method: "GET",
						contentType: "application/json",
						datatype: "json",
						async: false,
						success: function (result, xhr, data) {
							var projectList = result;
							var oRulesModel = [];
							var oModel = new sap.ui.model.json.JSONModel();
							oModel.setData({
								modeldata: projectList
							});

							for (var index = 0; index <= projectList.length - 1; index++) {
								var project = projectList[index];
								var projDesc = project.Description[0].Text;

								var projExprLang = "1.0";
								if (project.Annotations.length > 0) { // Get expression language from the annotations
									projExprLang = controller.getExpressionLanguage(project.Annotations);
								}

								delete project.Description; // As description is an array remove that from the structure
								delete project.Annotations; // As Annotation is an array remove that from the structure
								delete project.Version; // As Version is an array remove that from the structure
								delete project.Label; // As Labels is an array remove that from the structure

								project.Description = projDesc;
								project.ExpressionLanguage = projExprLang;
								var projectId = project.Id;

								var rulesMetadataArr = [];
								project.Rules = rulesMetadataArr;

								$.ajax({
									url: "/bpmrulesrepository/rest/v1/projects/" + projectId + "/rules",
									method: "GET",
									contentType: "application/json",
									datatype: "json",
									async: false,
									success: function (resultRules, xhrRules, dataRules) {
										var rulesList = resultRules;
										oRulesModel.push(resultRules);

										for (var ruleIndex = 0; ruleIndex <= rulesList.length - 1; ruleIndex++) {
											var ruleModel = rulesList[ruleIndex];
											var ruleDesc = ruleModel.Description[0].Text;
											delete ruleModel.Description; // As description is an array remove that from the structure
											ruleModel.Description = ruleDesc;

											var Rule = {};
											Rule.Id = ruleModel.Id;
											Rule.Name = ruleModel.Name;
											Rule.ProjectName = project.Name;
											Rule.ExpressionLanguage = project.ExpressionLanguage;
											Rule.Description = ruleDesc;
											Rule.Type = ruleModel.Type;
											rulesMetadataArr.push(Rule);

											oModel.setData({
												modeldata: projectList,
												rulesdata: oRulesModel
											});

											oModel.refresh(true);
											rulesProjectsList.setModel(oModel);
										}
									},
									error: function (result1, xhr1, data1) {
										result1.getResponseHeader("");
									}
								});
							}

							rulesProjectsList.setModel(oModel);
							rulesProjectsList.bindItems({
								path: "/modeldata",
								template: rulesProjectsListTemplate
							});

							var searchField = new sap.m.SearchField({
								search: controller.onSearch
							});
							var oMasterPage = new sap.m.Page({
								id: "ListRulesProjectsPage",
								title: "{i18n>title}",
								content: [searchField, rulesProjectsList]
							});

							var footerBar = new sap.m.Bar({
								contentRight: [editButton, saveButton, activateButton, checkButton, deployButton, cancelButton]
							});

							var oDetailPage = new sap.m.Page({
								id: "RuleDetailsPage",
								title: "{i18n>detailsPageTitle}",
								content: [header, decisionTable],
								footer: footerBar,
								showFooter: false,
								showHeader: false
							});

							oSplitter.addMasterPage(oMasterPage);
							oSplitter.addDetailPage(oDetailPage);

						},
						error: function (result1, xhr1, data1) {
							result1.getResponseHeader("");
						}
					});

					var app = new sap.m.App(); app.addPage(oSplitter);
					return app;
				}

			});